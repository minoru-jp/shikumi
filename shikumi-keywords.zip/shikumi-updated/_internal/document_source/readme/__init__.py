"""README canonical document source."""
