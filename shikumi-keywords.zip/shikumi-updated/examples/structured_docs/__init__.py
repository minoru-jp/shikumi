"""Structured-document realization example."""
